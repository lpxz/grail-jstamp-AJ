package Yada.java;

import java.util.List;



public class Barrier {

    public static void enterBarrier() {
    	System.out.print("");
    	int ji=9;
    	System.out.println(ji);
    	

    }

    public static void setBarrier(int x) {
    }
}
