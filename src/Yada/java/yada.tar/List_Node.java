package Yada.java;

public class List_Node {

    Object dataPtr;

    List_Node nextPtr;

    public List_Node() {
        dataPtr = null;
        nextPtr = null;
    }
}
