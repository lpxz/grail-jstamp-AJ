package Yada.java;

public class global_arg {

    public global_arg() {
    }

    int global_totalNumAdded;

    int global_numProcess;
}
