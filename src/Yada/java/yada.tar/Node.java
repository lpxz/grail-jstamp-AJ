package Yada.java;

public class Node {

    Object k;

    Object v;

    Node p;

    Node l;

    Node r;

    int c;

    public Node() {
    }
}
